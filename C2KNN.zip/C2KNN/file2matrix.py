from numpy import *
import matplotlib.pyplot as plt


def file2matrix(filename):
    fr = open(filename)
    arrayOLines = fr.readlines()
    numberOfLines = len(arrayOLines)  # 读出数据行数
    returnMat = zeros((numberOfLines, 3))  # 创建返回矩阵
    classLabelVector = []
    index = 0
    for line in arrayOLines:
        line = line.strip()  # 删除空白符
        listFromLine = line.split('\t')  # split指定分隔符对数据切片
        returnMat[index, :] = listFromLine[0:3]  # 选取前3个元素（特征）存储在返回矩阵中
        classLabelVector.append((listFromLine[-1]))
        # -1索引表示最后一列元素,位label信息存储在classLabelVector
        index += 1
    return returnMat, classLabelVector


if __name__ == '__main__':

    fig = plt.figure()
    ax = fig.add_subplot(111)
    datingDataMat, Labels = file2matrix('datingTestSet.txt')
    # ax.scatter(datingDataMat[:,1], datingDataMat[:,2])
    datingLabels = zeros(shape(Labels))
    for i in range(0, len(Labels)): # 替换为数字后，变为datingTestSet2.txt
        if Labels[i] == 'largeDoses':
            datingLabels[i] = 3
        elif Labels[i] == 'smallDoses':
            datingLabels[i] = 2
        elif Labels[i] == 'didntLike':
            datingLabels[i] = 1
    ax.scatter(datingDataMat[:, 1], datingDataMat[:, 2], 5.0 * array(datingLabels), 5.0 * array(datingLabels))
    ax.axis([-2, 25, -0.2, 2.0])
    plt.xlabel('Percentage of Time Spent Playing Video Games')
    plt.ylabel('Liters of Ice Cream Consumed Per Week')
    plt.show()
