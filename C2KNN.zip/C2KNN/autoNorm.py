# 归一化特征值
# 归一化公式  ：（当前值-最小值）/range
from numpy import *
from file2matrix import *

def autoNorm(dataSet):

    minVals = dataSet.min(0)  # 存放每列最小值，参数0使得可以从列中选取最小值，而不是当前行
    maxVals = dataSet.max(0)  # 存放每列最大值
    ranges = maxVals - minVals
    normDataSet = zeros(shape(dataSet))  # 初始化归一化矩阵为读取的dataSet
    m = dataSet.shape[0]  # m保存第一行
    # 特征矩阵是3x1000，min max range是1x3 因此采用tile将变量内容复制成输入矩阵同大小
    normDataSet = dataSet - tile(minVals, (m, 1))
    normDataSet = normDataSet / tile(ranges, (m, 1))
    return normDataSet, ranges, minVals


if __name__ == '__main__':
    datingDataMat, Labels = file2matrix('datingTestSet2.txt')
    normMat, ranges,minVals = autoNorm(datingDataMat)
    print(normMat,'\n\n', ranges,'\n\n', minVals)
