# createDataSet
import matplotlib.pyplot as plt
from KNN import classify0
from numpy import *


def createDataSet():
    group = array([[1.0, 1.1], [1.0, 1.0], [0, 0], [0, 0.1]])
    labels = ['A', 'A', 'B', 'B']
    return group, labels


if __name__ == '__main__':
    group, labels = createDataSet();
    print(group, '\n', labels)
    print(classify0([0.4, 0.4], group, labels, 3))
    for i in range(0, labels.__len__()):
        if labels[i] == 'A':
            plt.scatter(group[i, 0], group[i, 1], s=30, c='b', marker='+', )
        elif labels[i] == 'B':
            plt.scatter(group[i, 0], group[i, 1], s=30, c='r', marker='1')
    plt.legend(labels)
    plt.scatter([0.4, 0.6], [0.4, 0.7])
    plt.show()
